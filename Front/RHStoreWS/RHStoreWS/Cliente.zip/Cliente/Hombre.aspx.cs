﻿using RHStoreBaseBO.ServiciosWeb;
using RHStorePrendasBO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RHStoreWS.Cliente
{
    public partial class Hombre : System.Web.UI.Page
    {
        private PrendaBO prendaBO = new PrendaBO();

        protected void Page_Load(object sender, EventArgs e)
        {
   
        }

    }
}